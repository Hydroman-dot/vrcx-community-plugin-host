/* VRCX Community Host 1.0.0 | MIT | adapter v2026.09.16 */
;(function(){
"use strict";

const HOST_VERSION = '1.0.0';
const API_VERSION = 1;
const SUPPORTED_VRCX = ['2026.09.16'];
const isUserId = id => typeof id === 'string' && /^usr_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
const copy = value => JSON.parse(JSON.stringify(value));
const PERMISSIONS = ['events', 'users', 'blocks', 'storage', 'notifications', 'ui', 'network', 'updates'];
function validatePackage(pkg) {
    const m = pkg?.manifest;
    if (!m || !/^[a-z][a-z0-9-]{2,63}$/.test(m.id) || !/^\d+\.\d+\.\d+$/.test(m.version) || m.apiVersion !== API_VERSION ||
        typeof m.name !== 'string' || !m.name.trim() || m.name.length > 100 ||
        !Array.isArray(m.permissions) || m.permissions.some(p => !PERMISSIONS.includes(p)) ||
        !Array.isArray(m.vrcxVersions) || !m.vrcxVersions.length || m.vrcxVersions.some(v => !/^\d{4}\.\d{2}\.\d{2}$/.test(v)) ||
        typeof pkg.code !== 'string' || pkg.code.length > 500000) throw Error('Ungültiges Plugin-Paket oder nicht unterstützte API.');
    return copy(pkg);
}
function formatTemplate(template, person, category) {
    return template.replace(/\{(name|userId|category)\}/g, (_, k) => ({ name: person.displayName || person.userId, userId: person.userId, category })[k]);
}
function normalizePeople(input = {}) {
    const ids = value => [...new Set((Array.isArray(value) ? value : []).filter(isUserId))].slice(0, 10000);
    const templates = {};
    for (const key of ['general', 'blocked_me', 'blocked_by_me', 'shared']) {
        const t = input.messageTemplates?.[key];
        if (typeof t === 'string' && t.trim() && t.length <= 300) templates[key] = t;
    }
    return { version: 3, userIds: ids(input.userIds), blockedMeUserIds: ids(input.blockedMeUserIds),
        notifyBlockedUsers: input.notifyBlockedUsers !== false, messageTemplates: templates,
        sources: (Array.isArray(input.sources) ? input.sources : []).slice(0, 30).map(validateList) };
}
function validateList(value) {
    if (!value || typeof value.name !== 'string' || !value.name.trim() || value.name.length > 100 ||
        !Array.isArray(value.userIds) || value.userIds.length > 10000 || value.userIds.some(id => !isUserId(id))) throw Error('Liste benötigt name und höchstens 10000 gültige userIds.');
    let url = '';
    if (value.url) { const u = new URL(value.url); if (u.protocol !== 'https:' || u.username || u.password) throw Error('Listen-Abos benötigen HTTPS ohne Zugangsdaten in der URL.'); url = u.href; }
    return { name: value.name.trim(), userIds: [...new Set(value.userIds)], url,
        updatedAt: typeof value.updatedAt === 'string' ? value.updatedAt.slice(0, 40) : '', enabled: value.enabled !== false };
}
// Native live-log bridge only: the database history path never calls this tracker.
class Presence {
    constructor(emit, now = () => Date.now()) { this.emit = emit; this.now = now; this.reset(); }
    reset() { this.location = ''; this.players = new Map(); this.epoch = (this.epoch || 0) + 1; }
    accept(raw, accountId, running) {
        if (!running || !isUserId(accountId) || !Array.isArray(raw)) return;
        const age = this.now() - Date.parse(raw[1]);
        if (!Number.isFinite(age) || age < -5000 || age > 60000) return;
        const type = raw[2];
        if (type === 'vrc-quit') { this.reset(); this.emit('instance.left', {}); return; }
        if (type === 'location-destination') { this.reset(); this.emit('instance.travel', {}); return; }
        if (type === 'location') {
            if (typeof raw[3] !== 'string' || !/^wrld_[^:]+:.+/.test(raw[3])) { this.reset(); return; }
            if (this.location === raw[3]) return;
            this.reset(); this.location = raw[3]; this.enteredAt = this.now();
            this.emit('instance.entered', { location: this.location, worldName: String(raw[4] || ''), epoch: this.epoch, complete: false }); return;
        }
        if (!this.location || !isUserId(raw[4]) || raw[4] === accountId) return;
        const person = { userId: raw[4], displayName: String(raw[3] || ''), location: this.location, epoch: this.epoch,
            duringEntry: this.now() - this.enteredAt < 15000, historical: false };
        if (type === 'player-joined' && !this.players.has(person.userId)) {
            this.players.set(person.userId, person); this.emit('player.joined', copy(person));
        } else if (type === 'player-left' && this.players.delete(person.userId)) this.emit('player.left', person);
    }
    snapshot() { return { location: this.location, players: [...this.players.values()].map(copy), complete: false, epoch: this.epoch }; }
}
function serializedRepository(repository) {
    let queue = Promise.resolve();
    return { get: (key, fallback = null) => queue.then(async () => { const raw = await repository.getString(key, null); return raw === null ? copy(fallback) : JSON.parse(raw); }),
        set: (key, value) => { const raw = JSON.stringify(value); if (raw.length > 2000000) return Promise.reject(Error('Speicherlimit überschritten.'));
            const result = queue.then(() => repository.setString(key, raw)); queue = result.catch(() => {}); return result; } };
}


function createAdapter(w, emit, log) {
    const s = w.$pinia;
    if (!s?.gameLog || typeof s.gameLog.addGameLogEvent !== 'function' || !s.user || !s.game ||
        typeof s.notification?.playNoty !== 'function' || typeof w.configRepository?.setString !== 'function') throw Error('VRCX-Schnittstelle fehlt. Erweiterungen bleiben ausgeschaltet.');
    const presence = new Presence(emit);
    const original = s.gameLog.addGameLogEvent;
    let account = s.user.currentUser?.id || '';
    function live(raw) {
        const result = original.apply(this, arguments);
        try { syncAccount(); presence.accept(JSON.parse(raw), account, s.game.isGameRunning); }
        catch (error) { log('Log-Ereignis verworfen: ' + error.message); }
        return result;
    }
    s.gameLog.addGameLogEvent = live;
    function syncAccount() {
        const id = s.user.currentUser?.id || '';
        if (id !== account) { account = id; presence.reset(); emit('account.changed', { userId: isUserId(id) ? id : '' }); }
        if (!s.game.isGameRunning && presence.location) { presence.reset(); emit('instance.left', {}); }
    }
    const timer = w.setInterval(syncAccount, 1000);
    return {
        account: () => isUserId(s.user.currentUser?.id) ? s.user.currentUser.id : '',
        selected: () => { const d = s.user.userDialog; return d?.visible && isUserId(d.id) ? { userId: d.id, displayName: d.ref?.displayName || d.id } : null; },
        blocks: () => [...(s.moderation?.cachedPlayerModerations?.values() || [])]
            .filter(m => m.type === 'block' && !m.$isExpired && m.sourceUserId === s.user.currentUser?.id && isUserId(m.targetUserId))
            .map(m => ({ userId: m.targetUserId, displayName: m.targetDisplayName || m.targetUserId })),
        snapshot: () => presence.snapshot(),
        notify: message => s.notification.playNoty({ type: 'External', message, created_at: new Date().toISOString() }),
        dispose: () => { w.clearInterval(timer); if (s.gameLog.addGameLogEvent === live) s.gameLog.addGameLogEvent = original; }
    };
}
// Guard native calls too: store-internal closures bypass replacement store methods.
async function createUpdateGate(w, settings, save, log) {
    const updater = w.$pinia?.vrcxUpdater;
    const originals = [];
    let held = settings.holdUpdates !== false;
    function guard(object, key, predicate) {
        if (typeof object?.[key] !== 'function') throw Error('Update-Schutz fehlt: ' + key);
        const original = object[key];
        const wrapped = function (...args) {
            if (held && predicate(...args)) { log('Update angehalten. Erst im Plugin-Menü freigeben.'); throw Error('Community-Plugin-Manager: Update angehalten.'); }
            return original.apply(this, args);
        };
        object[key] = wrapped;
        if (object[key] !== wrapped) throw Error('Update-Schutz konnte nicht installiert werden.');
        originals.push(() => { if (object[key] === wrapped) object[key] = original; });
    }
    try {
        guard(w.AppApi, 'DownloadUpdate', () => true);
        guard(w.AppApi, 'RestartApplication', upgrade => Boolean(upgrade));
        if (settings.previousUpdateMode === undefined) {
            settings.previousUpdateMode = await w.configRepository.getString('VRCX_autoUpdateVRCX', 'Auto Download'); await save();
        }
        if (held) await updater.setAutoUpdateVRCX('Off');
    } catch (e) { originals.reverse().forEach(f => f()); throw e; }
    return {
        get held() { return held; },
        async set(value) {
            const old = held; held = value; settings.holdUpdates = value;
            try { await updater.setAutoUpdateVRCX(value ? 'Off' : settings.previousUpdateMode); await save(); }
            catch (e) {
                held = old; settings.holdUpdates = old;
                try { await updater.setAutoUpdateVRCX(old ? 'Off' : settings.previousUpdateMode); await save(); }
                catch (rollback) { log('Update-Einstellung bitte prüfen: ' + rollback.message); }
                throw e;
            }
        },
        dispose() { originals.reverse().forEach(f => f()); }
    };
}


const peopleManifest = { id: 'people-alerts', name: 'Personenlisten', version: '1.0.0', apiVersion: 1,
    vrcxVersions: ['2026.09.16'], permissions: ['events', 'users', 'blocks', 'storage', 'notifications', 'ui', 'network'] };
async function peoplePlugin(api) {
    let data = normalizePeople(await api.storage.get('lists', null) || await api.storage.legacyPeople() || {});
    const titles = { general: 'Warnliste', blocked_me: 'Hat mich blockiert (manuell)', blocked_by_me: 'Von mir blockiert', shared: 'Geteilte Liste' };
    const defaults = {
        general: '⚠ {name} aus deiner Warnliste ist in deiner Instanz.',
        blocked_me: '⚠ {name} ist in deiner Instanz: hat mich blockiert (manueller Eintrag).',
        blocked_by_me: '⚠ {name}, von dir blockiert, ist in deiner Instanz.',
        shared: '⚠ {name} aus {category} ist in deiner Instanz.'
    };
    let writes = Promise.resolve();
    const change = fn => {
        const job = writes.then(async () => { const next = normalizePeople(data); fn(next); await api.storage.set('lists', next); data = next; api.ui.refresh(); });
        writes = job.catch(() => {}); return job;
    };
    await api.storage.set('lists', data);
    function warn(person) {
        const reasons = [];
        if (data.userIds.includes(person.userId)) reasons.push(['general', titles.general]);
        if (data.blockedMeUserIds.includes(person.userId)) reasons.push(['blocked_me', titles.blocked_me]);
        if (data.notifyBlockedUsers && api.users.blocks().some(p => p.userId === person.userId)) reasons.push(['blocked_by_me', titles.blocked_by_me]);
        for (const source of data.sources) if (source.enabled && source.userIds.includes(person.userId)) reasons.push(['shared', source.name]);
        if (reasons.length) api.notifications.send(reasons.map(([key, category]) => formatTemplate(data.messageTemplates[key] || defaults[key], person, category)).join(' | ').slice(0, 1800));
    }
    api.events.on('player.joined', warn);
    // The adapter handles presence deduplication; this plugin never polls old log history.
    for (const [key, listKey] of [['general', 'userIds'], ['blocked_me', 'blockedMeUserIds']]) {
        api.ui.userAction({ id: key, label: titles[key] + ' umschalten', run: person => change(next => {
            const index = next[listKey].indexOf(person.userId);
            if (index < 0) next[listKey].push(person.userId); else next[listKey].splice(index, 1);
        }) });
    }
    api.ui.page({ id: 'people', title: 'Personenlisten', render: () => ({
        description: 'Markiere Personen hier per userId oder öffne ihr VRCX-Profil und nutze oben die Nutzer-Aktionen. „Hat mich blockiert“ ist ausschließlich deine manuelle Angabe. Warnungen erscheinen auch beim eigenen Beitritt, sobald VRChat die anwesenden Personen meldet.',
        fields: [ { id: 'userId', label: 'VRChat userId', type: 'text', value: '' },
            { id: 'notifyBlockedUsers', label: 'Bei meinen aktiven VRChat-Blocks warnen', type: 'checkbox', value: data.notifyBlockedUsers },
            ...Object.keys(titles).map(key => ({ id: key, label: titles[key] + ' – Meldung', type: 'text', value: data.messageTemplates[key] || defaults[key], maxLength: 300 })),
            { id: 'listJson', label: 'Geteilte Liste als JSON (name, userIds)', type: 'textarea', value: '' },
            { id: 'feedUrl', label: 'HTTPS-Adresse einer geteilten Liste (nur lesend)', type: 'text', value: '' } ],
        hint: 'Platzhalter: {name}, {userId}, {category}. VRCX-Einstellungen für Overlay, Desktop, TTS und „Beschäftigt“ gelten weiterhin. Abos werden beim Anklicken aktualisiert; keine automatische Veröffentlichung.',
        actions: [{ id: 'add-general', label: 'Zur Warnliste' }, { id: 'add-blocked', label: 'Zu „Hat mich blockiert“' },
            { id: 'save', label: 'Meldungen speichern' }, { id: 'reset', label: 'Standardmeldungen' }, { id: 'preview', label: 'Testmeldung senden' },
            { id: 'export', label: 'Meine Warnliste teilen' }, { id: 'backup', label: 'Alle Listen und Meldungen sichern' },
            { id: 'restore', label: 'Sicherung aus JSON wiederherstellen' }, { id: 'import', label: 'Geteilte Liste importieren' }, { id: 'subscribe', label: 'Listen-Abo hinzufügen' }],
        rows: [ ...data.userIds.map(id => ({ text: 'Warnliste · ' + id, action: 'remove-general:' + id, label: 'Entfernen' })),
            ...data.blockedMeUserIds.map(id => ({ text: 'Hat mich blockiert (manuell) · ' + id, action: 'remove-blocked:' + id, label: 'Entfernen' })),
            ...api.users.blocks().map(p => ({ text: 'Von mir blockiert (VRChat) · ' + p.displayName + ' · ' + p.userId })),
            ...data.sources.flatMap((s, i) => [ { text: `${s.name} · ${s.userIds.length} Personen · ${s.enabled ? 'aktiv' : 'pausiert'} · ${s.updatedAt || 'importiert'}${s.url ? ' · ' + s.url : ''}`, action: 'toggle-source:' + i, label: 'Aktiv/Pause' },
                ...(s.url ? [{ text: s.name, action: 'refresh-source:' + i, label: 'Abo aktualisieren' }] : []),
                { text: s.name, action: 'remove-source:' + i, label: 'Liste entfernen' } ]) ]
    }), async onAction(action, values) {
        const person = { userId: values.userId?.trim(), displayName: 'Beispielperson' };
        if (action.startsWith('add-')) {
            if (!isUserId(person.userId)) throw Error('Bitte eine gültige usr_…-ID eingeben.');
            await change(next => { const key = action === 'add-general' ? 'userIds' : 'blockedMeUserIds'; if (!next[key].includes(person.userId)) next[key].push(person.userId); });
        } else if (action.startsWith('remove-general:') || action.startsWith('remove-blocked:')) {
            const [kind, id] = action.split(':'); await change(next => { const key = kind === 'remove-general' ? 'userIds' : 'blockedMeUserIds'; next[key] = next[key].filter(x => x !== id); });
        } else if (action === 'save') {
            for (const key of Object.keys(titles)) if (!values[key]?.trim() || values[key].length > 300) throw Error('Meldungen benötigen 1 bis 300 Zeichen.');
            await change(next => { next.notifyBlockedUsers = values.notifyBlockedUsers; next.messageTemplates = Object.fromEntries(Object.keys(titles).map(k => [k, values[k]])); });
        } else if (action === 'reset') await change(next => { next.messageTemplates = {}; });
        else if (action === 'preview') api.notifications.send(formatTemplate(values.general || defaults.general, { ...person, userId: isUserId(person.userId) ? person.userId : 'usr_00000000-0000-0000-0000-000000000000' }, titles.general));
        else if (action === 'export') api.ui.download('meine-warnliste.json', { name: 'Geteilte Warnliste', userIds: data.userIds });
        else if (action === 'backup') api.ui.download('personenlisten-sicherung.json', { kind: 'vrcx-people-backup', data });
        else if (action === 'restore') {
            const backup = JSON.parse(values.listJson);
            if (backup.kind !== 'vrcx-people-backup' || backup.data?.version !== 3) throw Error('Keine gültige Personenlisten-Sicherung.');
            if (api.ui.confirm('Alle lokalen Personenlisten und Meldungstexte durch diese Sicherung ersetzen?')) await change(next => Object.assign(next, normalizePeople(backup.data)));
        }
        else if (action === 'import' || action === 'subscribe') {
            const list = action === 'import' ? validateList(JSON.parse(values.listJson)) : validateList({ ...await api.network.json(values.feedUrl), url: values.feedUrl, updatedAt: new Date().toISOString() });
            await change(next => { if (next.sources.length >= 30) throw Error('Höchstens 30 geteilte Listen.'); next.sources.push(list); });
        } else if (action.startsWith('refresh-source:')) {
            const index = Number(action.split(':')[1]), old = data.sources[index];
            const list = validateList({ ...await api.network.json(old.url), url: old.url, enabled: old.enabled, updatedAt: new Date().toISOString() });
            await change(next => { if (next.sources[index]?.url !== old.url) throw Error('Liste wurde zwischenzeitlich geändert.'); next.sources[index] = list; });
        } else if (action.startsWith('remove-source:')) await change(next => { next.sources.splice(Number(action.split(':')[1]), 1); });
        else if (action.startsWith('toggle-source:')) await change(next => { const s = next.sources[Number(action.split(':')[1])]; s.enabled = !s.enabled; });
    } });
}


async function startHost(w = window) {
    if (w.VRCXCommunityHost) return;
    const repository = serializedRepository(w.configRepository);
    const key = 'VRCX_CommunityHost_v1';
    const settings = await repository.get(key, { holdUpdates: true, plugins: {}, origins: {} });
    settings.plugins ||= {}; settings.origins ||= {};
    const save = () => repository.set(key, settings);
    const logs = [], active = new Map(), pages = new Map(), userActions = new Map(), events = new Map();
    let adapter, gate, disposed = false, selectedPage = '', renderUI = () => {};
    const log = message => { logs.unshift(new Date().toLocaleTimeString() + ' · ' + String(message).slice(0, 500)); logs.length = Math.min(logs.length, 80); };
    const version = String(await w.AppApi.GetVersion()).trim().replace(/^VRCX /, '');
    const compatible = SUPPORTED_VRCX.includes(version);
    const updateStatus = () => ({ vrcxVersion: version, hostVersion: HOST_VERSION, held: Boolean(gate?.held),
        supportedVrcxVersions: [...SUPPORTED_VRCX], compatible, automaticInstallation: false });
    const emit = (name, value) => { for (const fn of [...(events.get(name) || [])]) fn(copy(value)); };
    try { gate = await createUpdateGate(w, settings, save, log); }
    catch (e) { log('Update-Schutz nicht verfügbar: ' + e.message); }
    if (compatible && gate) adapter = createAdapter(w, emit, log);
    function stop(id) {
        const state = active.get(id); if (!state) return;
        state.stopped = true; for (const clean of state.cleanup.reverse()) { try { clean(); } catch (e) { log(id + ': ' + e.message); } }
        active.delete(id); for (const [k, p] of pages) if (p.owner === id) pages.delete(k);
        for (const [k, a] of userActions) if (a.owner === id) userActions.delete(k);
    }
    async function run(manifest, activate) {
        if (!adapter || !gate?.held || !manifest.vrcxVersions.includes(version) || settings.plugins[manifest.id]?.enabled === false) return;
        const state = { cleanup: [], errors: 0, stopped: false }; active.set(manifest.id, state);
        const ensure = permission => { if (state.stopped || disposed) throw Error('Plugin ist beendet.'); if (!manifest.permissions.includes(permission)) throw Error('Fehlende Berechtigung: ' + permission); };
        function safe(fn) { return async (...args) => {
            if (state.stopped) return;
            try { return await fn(...args); } catch (e) { log(manifest.name + ': ' + e.message); if (++state.errors >= 3) { stop(manifest.id); log(manifest.name + ' nach drei Fehlern für diese Sitzung pausiert.'); renderUI(); } throw e; }
        }; }
        const storageKey = (name, scope) => {
            ensure('storage'); if (!/^[a-zA-Z0-9_-]{1,80}$/.test(name)) throw Error('Ungültiger Speicherschlüssel.');
            if (scope !== 'local' && scope !== 'account') throw Error('Speicherbereich muss local oder account sein.');
            const account = scope === 'account' ? adapter.account() : 'local'; if (!account) throw Error('Kein angemeldetes Konto.');
            return `CommunityPlugin_${manifest.id}_${account}_${name}`;
        };
        const api = Object.freeze({ version: API_VERSION, hostVersion: HOST_VERSION,
            updates: Object.freeze({ status() { ensure('updates'); return updateStatus(); } }),
            events: Object.freeze({ on(name, handler) {
                ensure('events'); if (!['player.joined', 'player.left', 'instance.entered', 'instance.left', 'instance.travel', 'account.changed'].includes(name) || typeof handler !== 'function') throw Error('Unbekanntes Ereignis.');
                if (!events.has(name)) events.set(name, new Set());
                const wrapped = value => { void safe(handler)(value).catch(() => {}); }; events.get(name).add(wrapped);
                const off = () => events.get(name)?.delete(wrapped); state.cleanup.push(off); return off;
            } }),
            users: Object.freeze({ current: () => { ensure('users'); return { userId: adapter.account() }; },
                selected: () => { ensure('users'); return copy(adapter.selected()); },
                presence: () => { ensure('users'); return adapter.snapshot(); },
                blocks: () => { ensure('blocks'); return copy(adapter.blocks()); } }),
            storage: Object.freeze({ get: (name, fallback = null, scope = 'local') => repository.get(storageKey(name, scope), fallback),
                set: (name, value, scope = 'local') => repository.set(storageKey(name, scope), value),
                async legacyPeople() { ensure('storage'); if (manifest.id !== 'people-alerts') throw Error('Nur Migration des eingebauten Plugins.');
                    return await repository.get('VRCX_PersonWatchlist_v2', null) || await repository.get('VRCX_PersonWatchlist_v1', null); } }),
            notifications: Object.freeze({ send(message) { ensure('notifications'); if (typeof message !== 'string' || !message.trim() || message.length > 1800) throw Error('Meldung benötigt 1 bis 1800 Zeichen.');
                const now = Date.now(); state.notices = (state.notices || []).filter(t => now - t < 10000);
                if (state.notices.length >= 25) { log(manifest.name + ': Meldungsrate begrenzt.'); return; }
                state.notices.push(now); adapter.notify(message); } }),
            ui: Object.freeze({ page(page) { ensure('ui'); if (!/^[a-z][a-z0-9-]{0,40}$/.test(page.id) || typeof page.render !== 'function' || typeof page.onAction !== 'function') throw Error('Ungültige Seite.');
                pages.set(manifest.id + ':' + page.id, { ...page, owner: manifest.id, onAction: safe(page.onAction) }); },
                userAction(action) { ensure('ui'); if (!action.id || typeof action.run !== 'function') throw Error('Ungültige Nutzer-Aktion.');
                    userActions.set(manifest.id + ':' + action.id, { ...action, owner: manifest.id, run: safe(action.run) }); },
                refresh() { ensure('ui'); renderUI(); }, download(name, data) { ensure('ui'); download(name, data); },
                confirm(message) { ensure('ui'); return w.confirm(String(message)); } }),
            network: Object.freeze({ async json(address) {
                ensure('network'); const url = new URL(address); if (url.protocol !== 'https:' || url.username || url.password) throw Error('Nur HTTPS ohne eingebettete Zugangsdaten.');
                const grant = manifest.id + ':' + url.origin;
                if (!settings.origins[grant]) {
                    if (!w.confirm(`${manifest.name} möchte eine JSON-Liste von ${url.origin} abrufen. Die Website sieht dabei deine IP-Adresse. Zugriff auf diese Herkunft erlauben?`)) throw Error('Netzwerkzugriff abgelehnt.');
                    settings.origins[grant] = true; await save();
                }
                const controller = new AbortController(); const timer = w.setTimeout(() => controller.abort(), 15000);
                state.cleanup.push(() => controller.abort());
                try { const response = await w.fetch(url.href, { credentials: 'omit', redirect: 'error', signal: controller.signal, referrerPolicy: 'no-referrer' });
                    if (!response.ok) throw Error('HTTP ' + response.status);
                    const reader = response.body.getReader(); let size = 0, text = ''; const decoder = new TextDecoder();
                    while (true) { const { done, value } = await reader.read(); if (done) break; size += value.byteLength;
                        if (size > 2000000) { await reader.cancel(); throw Error('Liste größer als 2 MB.'); } text += decoder.decode(value, { stream: true }); }
                    text += decoder.decode(); ensure('network'); return JSON.parse(text);
                } finally { w.clearTimeout(timer); }
            } }),
            lifecycle: Object.freeze({ onDispose(fn) { if (typeof fn !== 'function') throw Error('Funktion erwartet.'); state.cleanup.push(fn); } }),
            log: message => log(manifest.name + ': ' + message)
        });
        try { const dispose = await activate(api); if (typeof dispose === 'function') state.cleanup.push(dispose); }
        catch (error) { log(manifest.name + ' konnte nicht starten: ' + error.message); stop(manifest.id); }
    }
    async function start(id) {
        stop(id);
        if (id === peopleManifest.id) await run(peopleManifest, peoplePlugin);
        else {
            const pkg = validatePackage(settings.plugins[id]?.package);
            // Explicitly trusted local code, NOT a security sandbox (documented in import UI).
            await run(pkg.manifest, new Function('api', '"use strict"; return (async () => {\n' + pkg.code + '\n})();'));
        }
    }
    function download(name, data) {
        const url = w.URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
        const a = w.document.createElement('a'); a.href = url; a.download = name; a.click(); w.setTimeout(() => w.URL.revokeObjectURL(url), 5000);
    }
    function el(tag, text, parent) { const e = w.document.createElement(tag); if (text !== undefined) e.textContent = text; if (parent) parent.append(e); return e; }
    const container = el('div'); container.id = 'vrcx-community-host'; w.document.body.append(container);
    const root = container.attachShadow({ mode: 'open' });
    el('style', ':host{font:14px system-ui;color:#eee}*{box-sizing:border-box}button,input,textarea{font:inherit}button{background:#365976;color:white;border:1px solid #789;border-radius:5px;padding:7px 10px;cursor:pointer;margin:3px}button:hover{background:#467b9c}input,textarea{background:#18232c;color:#fff;border:1px solid #738391;border-radius:4px;padding:7px;width:100%}input[type=checkbox]{width:auto}textarea{min-height:75px}label{display:block;margin:10px 0}p{line-height:1.5;color:#cad7e0}h2,h3{margin:10px 0}.launch{position:fixed;right:14px;bottom:14px;z-index:2147483646}.panel{position:fixed;inset:5vh 5vw;z-index:2147483647;background:#14212b;border:1px solid #6d879b;border-radius:12px;padding:20px;overflow:auto;box-shadow:0 12px 60px #0009}.row{border-top:1px solid #41515d;padding:8px 0;overflow-wrap:anywhere}.error{color:#ffbc98;white-space:pre-wrap}.status{background:#243b4b;padding:10px;border-radius:6px}.close{float:right}pre{white-space:pre-wrap;overflow-wrap:anywhere}', root);
    const launcher = el('button', 'Plugins · Personenlisten', root); launcher.className = 'launch';
    const panel = el('section', undefined, root); panel.className = 'panel'; panel.hidden = true;
    panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'VRCX Community-Plugins');
    launcher.onclick = () => { panel.hidden = !panel.hidden; if (!panel.hidden) renderUI(); };
    root.addEventListener('keydown', e => { if (e.key === 'Escape') { panel.hidden = true; launcher.focus(); } });
    let message = '';
    function button(parent, label, callback) {
        const b = el('button', label, parent); b.onclick = async () => { b.disabled = true; try { await callback(); message = ''; }
            catch (e) { message = e.message; log(e.message); } finally { b.disabled = false; renderUI(); } }; return b;
    }
    renderUI = () => {
        if (panel.hidden || disposed) return;
        panel.replaceChildren(); button(panel, 'Schließen', () => { panel.hidden = true; launcher.focus(); }).className = 'close';
        el('h2', 'Community-Plugins · ' + HOST_VERSION, panel);
        el('p', `VRCX ${version} · API ${API_VERSION} · ${adapter ? 'Adapter aktiv' : 'Plugins pausiert: Version oder Schnittstelle nicht freigegeben'} · ${gate?.held ? 'Updates angehalten' : 'Updates nicht gesperrt'}`, panel).className = 'status';
        if (message) el('p', message, panel).className = 'error';
        const tabs = el('nav', undefined, panel); button(tabs, 'Plugin-Verwaltung', () => { selectedPage = ''; });
        for (const [id, page] of pages) button(tabs, page.title, () => { selectedPage = id; });
        const selected = adapter?.selected();
        if (selected) { const box = el('div', undefined, panel); el('h3', 'Geöffnetes VRCX-Profil: ' + selected.displayName, box);
            for (const action of userActions.values()) button(box, action.label, () => action.run(copy(selected))); }
        if (pages.has(selectedPage)) {
            const page = pages.get(selectedPage); let model;
            try { model = page.render(); } catch (e) { el('p', e.message, panel); return; }
            el('h3', page.title, panel); el('p', model.description || '', panel);
            const inputs = new Map();
            for (const field of (model.fields || []).slice(0, 100)) {
                const label = el('label', field.label, panel), input = el(field.type === 'textarea' ? 'textarea' : 'input', undefined, label);
                if (field.type !== 'textarea') input.type = field.type === 'checkbox' ? 'checkbox' : 'text';
                if (field.type === 'checkbox') input.checked = Boolean(field.value); else input.value = String(field.value ?? '');
                input.maxLength = field.maxLength || 1000000; inputs.set(field.id, input);
            }
            const values = () => Object.fromEntries([...inputs].map(([id, input]) => [id, input.type === 'checkbox' ? input.checked : input.value]));
            el('p', model.hint || '', panel);
            for (const action of (model.actions || []).slice(0, 50)) button(panel, action.label, () => page.onAction(action.id, values()));
            for (const row of (model.rows || []).slice(0, 20000)) { const line = el('div', row.text, panel); line.className = 'row'; if (row.action) button(line, row.label || 'Ausführen', () => page.onAction(row.action, values())); }
            return;
        }
        el('p', 'Plugins laufen als vertrauenswürdiger JavaScript-Code in VRCX und können technisch auf dessen Sitzung zugreifen. Berechtigungen strukturieren die API; sie sind keine Sicherheits-Sandbox. Installiere nur Code, dessen Herkunft und Inhalt du vertraust.', panel);
        const installed = [peopleManifest, ...Object.values(settings.plugins).filter(p => p.package).map(p => p.package.manifest)];
        for (const manifest of installed) {
            const row = el('div', `${manifest.name} ${manifest.version} · ${active.has(manifest.id) ? 'aktiv' : 'inaktiv'} · ${manifest.permissions.join(', ')}`, panel); row.className = 'row';
            const enabled = settings.plugins[manifest.id]?.enabled !== false;
            button(row, enabled ? 'Deaktivieren' : 'Aktivieren', async () => { settings.plugins[manifest.id] ||= {}; settings.plugins[manifest.id].enabled = !enabled;
                await save(); if (enabled) stop(manifest.id); else await start(manifest.id); });
            if (manifest.id !== peopleManifest.id) button(row, 'Entfernen', async () => { stop(manifest.id); delete settings.plugins[manifest.id]; await save(); });
        }
        const label = el('label', 'Plugin installieren oder aktualisieren (.json)', panel), input = el('input', undefined, label); input.type = 'file'; input.accept = '.json,application/json';
        input.onchange = async () => {
            try { const file = input.files?.[0]; if (!file) return; if (file.size > 1000000) throw Error('Plugin-Paket zu groß.');
                const pkg = validatePackage(JSON.parse(await file.text())); if (pkg.manifest.id === peopleManifest.id) throw Error('Das eingebaute Plugin wird mit dem Manager aktualisiert.');
                if (!pkg.manifest.vrcxVersions.includes(version)) throw Error('Plugin unterstützt diese VRCX-Version nicht.');
                const m = pkg.manifest;
                if (!w.confirm(`${m.name} ${m.version}\nBerechtigungen: ${m.permissions.join(', ')}\n\nVertrauenswürdigen Code installieren? Der Code hat technisch Zugriff auf deine VRCX-Sitzung.`)) return;
                const previous = settings.plugins[m.id]; settings.plugins[m.id] = { enabled: true, package: pkg };
                try { await save(); } catch (e) { if (previous) settings.plugins[m.id] = previous; else delete settings.plugins[m.id]; throw e; }
                await start(m.id); message = 'Plugin gespeichert. Status siehe oben.';
            } catch (e) { message = e.message; } renderUI();
        };
        el('h3', 'Updates und Wiederherstellung', panel);
        el('p', 'Der Manager bleibt bei VRCX-Updates im Benutzerordner erhalten. Nur ausdrücklich freigegebene Versionen starten Plugins. Aktuell freigegeben: ' + SUPPORTED_VRCX.join(', ') + '. Eine neue Version benötigt zuerst einen geprüften Manager-Adapter. Externe Installationsprogramme werden nicht blockiert.', panel);
        button(panel, 'Offizielle VRCX-Version prüfen', async () => {
            const controller = new AbortController(), timer = w.setTimeout(() => controller.abort(), 15000);
            try {
                const response = await w.fetch('https://api.github.com/repos/vrcx-team/VRCX/releases/latest', { credentials: 'omit', redirect: 'error', signal: controller.signal, referrerPolicy: 'no-referrer' });
                if (!response.ok) throw Error('Versionsprüfung: HTTP ' + response.status);
                const release = await response.json(), latest = String(release.tag_name || '').replace(/^v/, '');
                if (!/^\d{4}\.\d{2}\.\d{2}$/.test(latest)) throw Error('Unbekanntes Release-Format.');
                log('Offizielle stabile Version: ' + latest + (SUPPORTED_VRCX.includes(latest) ? ' · Manager freigegeben.' : ' · Update bleibt gesperrt, bis ein passender Manager vorliegt.'));
            } finally { w.clearTimeout(timer); }
        });
        if (gate) button(panel, gate.held ? 'Updates freigeben und Plugins pausieren' : 'Update-Schutz einschalten', async () => {
            if (gate.held) {
                if (!w.confirm('Plugins für diese Sitzung pausieren und normale VRCX-Updates wieder erlauben? Vor einem Update deine Listen exportieren.')) return;
                for (const id of [...active.keys()]) stop(id); await gate.set(false);
            } else { await gate.set(true); await start(peopleManifest.id);
                for (const id of Object.keys(settings.plugins)) if (id !== peopleManifest.id && settings.plugins[id].package) await start(id); }
        });
        button(panel, 'Manager-Einstellungen exportieren', () => download('community-manager.json', { version: 1, settings }));
        const backupLabel = el('label', 'Manager-Sicherung wiederherstellen (.json)', panel), backupInput = el('input', undefined, backupLabel);
        backupInput.type = 'file'; backupInput.accept = '.json,application/json';
        backupInput.onchange = async () => {
            try {
                const file = backupInput.files?.[0]; if (!file) return; if (file.size > 2000000) throw Error('Manager-Sicherung zu groß.');
                const backup = JSON.parse(await file.text());
                if (backup.version !== 1 || !backup.settings?.plugins || typeof backup.settings.plugins !== 'object' || Array.isArray(backup.settings.plugins)) throw Error('Ungültige Manager-Sicherung.');
                const plugins = {};
                for (const [id, record] of Object.entries(backup.settings.plugins)) {
                    if (id === peopleManifest.id) plugins[id] = { enabled: record.enabled !== false };
                    else { const pkg = validatePackage(record.package); if (pkg.manifest.id !== id) throw Error('Plugin-ID in Sicherung stimmt nicht überein.'); plugins[id] = { enabled: record.enabled !== false, package: pkg }; }
                }
                const names = Object.values(plugins).filter(p => p.package).map(p => `${p.package.manifest.name}: ${p.package.manifest.permissions.join(', ')}`);
                if (!w.confirm('Installierte Plugin-Pakete durch die Sicherung ersetzen? Enthaltener Code kann auf deine VRCX-Sitzung zugreifen. Netzwerkfreigaben werden zurückgesetzt.\n' + names.join('\n'))) return;
                const previous = { plugins: settings.plugins, origins: settings.origins };
                settings.plugins = plugins; settings.origins = {};
                try { await save(); } catch (e) { settings.plugins = previous.plugins; settings.origins = previous.origins; throw e; }
                for (const id of [...active.keys()]) stop(id);
                await start(peopleManifest.id);
                for (const id of Object.keys(plugins)) if (id !== peopleManifest.id) await start(id);
                message = 'Manager-Sicherung übernommen. Personenlisten und Update-Schutz bleiben separat erhalten.';
            } catch (e) { message = e.message; } renderUI();
        };
        button(panel, 'Netzwerkfreigaben zurücksetzen', async () => { settings.origins = {}; await save(); });
        el('p', 'Manager-Export enthält Plugin-Code, aber keine Personenlisten. Personenlisten separat auf deren Seite sichern. Beim Deinstallieren bleiben Listen gespeichert. Für VRCX-Updates zuerst oben freigeben.', panel);
        el('h3', 'Diagnose (diese Sitzung)', panel); el('pre', logs.join('\n') || 'Keine Fehler.', panel);
    };
    const publicHost = { version: HOST_VERSION, apiVersion: API_VERSION, vrcxVersion: version,
        status: () => ({ compatible, updateHeld: Boolean(gate?.held), active: [...active.keys()], logs: [...logs] }),
        dispose() { disposed = true; for (const id of [...active.keys()]) stop(id); adapter?.dispose(); gate?.dispose(); container.remove(); delete w.VRCXCommunityHost; } };
    w.VRCXCommunityHost = publicHost;
    await start(peopleManifest.id);
    for (const id of Object.keys(settings.plugins)) if (id !== peopleManifest.id && settings.plugins[id].package) {
        try { await start(id); } catch (e) { log(id + ': ' + e.message); }
    }
    return publicHost;
}


void startHost().then(host => {
    if (host) console.info('Community-Plugins gestartet: ' + JSON.stringify(host.status()));
}).catch(error => {
    console.error('VRCX Community Host', error);
    const note = document.createElement('div'); note.textContent = 'Community-Plugins konnten nicht starten: ' + error.message;
    note.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483647;background:#602d21;color:white;padding:16px;max-width:500px';
    document.body.append(note);
});


})();
