import { Presence, isUserId } from './core.js';
export function createAdapter(w, emit, log) {
    const s = w.$pinia;
    if (!s?.gameLog || typeof s.gameLog.addGameLogEvent !== 'function' || !s.user || !s.game ||
        typeof s.notification?.playNoty !== 'function' || typeof w.configRepository?.setString !== 'function') throw Error('VRCX-Schnittstelle fehlt. Erweiterungen bleiben ausgeschaltet.');
    const presence = new Presence(emit);
    const original = s.gameLog.addGameLogEvent;
    let account = s.user.currentUser?.id || '';
    function live(raw) {
        const result = original.apply(this, arguments);
        try { syncAccount(); presence.accept(JSON.parse(raw), account, s.game.isGameRunning); }
        catch (error) { log('Log-Ereignis verworfen: ' + error.message); }
        return result;
    }
    s.gameLog.addGameLogEvent = live;
    function syncAccount() {
        const id = s.user.currentUser?.id || '';
        if (id !== account) { account = id; presence.reset(); emit('account.changed', { userId: isUserId(id) ? id : '' }); }
        if (!s.game.isGameRunning && presence.location) { presence.reset(); emit('instance.left', {}); }
    }
    const timer = w.setInterval(syncAccount, 1000);
    return {
        account: () => isUserId(s.user.currentUser?.id) ? s.user.currentUser.id : '',
        selected: () => { const d = s.user.userDialog; return d?.visible && isUserId(d.id) ? { userId: d.id, displayName: d.ref?.displayName || d.id } : null; },
        blocks: () => [...(s.moderation?.cachedPlayerModerations?.values() || [])]
            .filter(m => m.type === 'block' && !m.$isExpired && m.sourceUserId === s.user.currentUser?.id && isUserId(m.targetUserId))
            .map(m => ({ userId: m.targetUserId, displayName: m.targetDisplayName || m.targetUserId })),
        snapshot: () => presence.snapshot(),
        notify: message => s.notification.playNoty({ type: 'External', message, created_at: new Date().toISOString() }),
        dispose: () => { w.clearInterval(timer); if (s.gameLog.addGameLogEvent === live) s.gameLog.addGameLogEvent = original; }
    };
}
// Guard native calls too: store-internal closures bypass replacement store methods.
export async function createUpdateGate(w, settings, save, log) {
    const updater = w.$pinia?.vrcxUpdater;
    const originals = [];
    let held = settings.holdUpdates !== false;
    function guard(object, key, predicate) {
        if (typeof object?.[key] !== 'function') throw Error('Update-Schutz fehlt: ' + key);
        const original = object[key];
        const wrapped = function (...args) {
            if (held && predicate(...args)) { log('Update angehalten. Erst im Plugin-Menü freigeben.'); throw Error('Community-Plugin-Manager: Update angehalten.'); }
            return original.apply(this, args);
        };
        object[key] = wrapped;
        if (object[key] !== wrapped) throw Error('Update-Schutz konnte nicht installiert werden.');
        originals.push(() => { if (object[key] === wrapped) object[key] = original; });
    }
    try {
        guard(w.AppApi, 'DownloadUpdate', () => true);
        guard(w.AppApi, 'RestartApplication', upgrade => Boolean(upgrade));
        if (settings.previousUpdateMode === undefined) {
            settings.previousUpdateMode = await w.configRepository.getString('VRCX_autoUpdateVRCX', 'Auto Download'); await save();
        }
        if (held) await updater.setAutoUpdateVRCX('Off');
    } catch (e) { originals.reverse().forEach(f => f()); throw e; }
    return {
        get held() { return held; },
        async set(value) {
            const old = held; held = value; settings.holdUpdates = value;
            try { await updater.setAutoUpdateVRCX(value ? 'Off' : settings.previousUpdateMode); await save(); }
            catch (e) {
                held = old; settings.holdUpdates = old;
                try { await updater.setAutoUpdateVRCX(old ? 'Off' : settings.previousUpdateMode); await save(); }
                catch (rollback) { log('Update-Einstellung bitte prüfen: ' + rollback.message); }
                throw e;
            }
        },
        dispose() { originals.reverse().forEach(f => f()); }
    };
}
